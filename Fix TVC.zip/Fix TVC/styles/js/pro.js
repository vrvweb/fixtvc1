function changeColour(element) {
  var div = document.getElementById('image-holder');
  if (element.id == 'a' && element.checked) {
    div.style.width = '50%';
    div.style.height = 'auto';
  } else if (element.id == 'b' && element.checked) {
    div.style.width = '80%';
    div.style.height = 'auto';
  } else if (element.id == 'c' && element.checked) {
    div.style.width = '100%';
    div.style.height = 'auto';

  }
}

/*
jQuery event that triggers when the button is pressed
# is an ID jQuery selector, usage:#anyElementId
*/
$('#btnClick').on('click',function(){
    
/*
In CSS, you can check if an element is visible by checking if the property display value is different from none, because if it's value is none, it will not be visible
*/
    if($('#1').css('display')!='none'){
/*    
So, if div 1 is visible, the condition will be true
*/
    $('#2').html($('#static').html()).show().siblings('div').hide();
        
/*
When you use it with parameter, example:
.html('<div><b>Any</b> plain text or HTML you want here.</div>')
It set the element HTML to whatever you put on it's parameter

When you use the method .html() without parameter, it returns the element HTML, so by using $('#static').html(), it will return the HTML from the DIV with ID static.

So I'm setting the DIV 2 HTML to whatever is static HTML

Right after setting the HTML, I use .show() to show div 2, and right after that I use .siblings('div').hide(), to hide any DIV siblings of the one I've just have showed up.

In jQuery, you can use methods to run synchronously, concatenating them with dots, example:
$('#div1').show().siblings('div').hide();

In this example it will show #div1 then right after that search for it div siblings and hide them.
*/
    }else if($('#2').css('display')!='none'){
/*    
Condition to check if DIV 2 is visible
*/
        $('#1').show().siblings('div').hide();
/*    
If it is, it will show DIV 1 and right after that will search for it siblings and hide them with .siblings('div').hide();
*/
    }
});

$(document).ready(function() {
        $("#fileUpload").on('change', function() {
          //Get count of selected files
          var countFiles = $(this)[0].files.length;
          var imgPath = $(this)[0].value;
          var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
          var image_holder = $("#image-holder");
          image_holder.empty();

          if (extn == "svg" || extn == "png" || extn == "jpeg" || extn == "ai") {
            if (typeof(FileReader) != "undefined") {
              //loop for each file selected for uploaded.
              for (var i = 0; i < countFiles; i++) 
              {
                var reader = new FileReader();
                reader.onload = function(e) {
                  $("<img />", {
                    "src": e.target.result,
                    "class": "thumb-image"
                  }).appendTo(image_holder);
                }
                image_holder.show();
                reader.readAsDataURL($(this)[0].files[i]);
              }
            } else {
              alert("Ce navigateur présente des problèmes avec notre site web.");
            }
          } else {
              swal({
  title: "Extension non valide",
  text: "Seuls les formats PNG, SVG, JPEG et Ai sont acceptés.",
  icon: "warning",
  button: "Réessayer",

})
          }

        });
      });

image = 1;
images = Array('|',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
  '/images/planet-noir.png',
  '/images/planet-blanc.png',
'|');


image2 = 1;
images2 = Array('|',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
  '/images/wifi-noir.png',
  '/images/wifi-blanc.png',
'|');

image3 = 1;
images3 = Array('|',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
  '/images/carre-noir.png',
  '/images/carre-blanc.png',
'|');

function imageSuivante() {
  new_image = images[image + 1]
  if(new_image != '|') {
      document.getElementById('planet').src = new_image;
      image = image + 1;
  }

new_image2 = images2[image2 + 1]
  if(new_image2 != '|') {
      document.getElementById('wifi').src = new_image2;
      image2 = image2 + 1;
  }

new_image3 = images3[image3 + 1]
  if(new_image3 != '|') {
      document.getElementById('carre').src = new_image3;
      image3 = image3 + 1;
  }

}

function imagePrecedente() {
  new_image = images[image - 1]
  if(new_image != '|') {
      document.getElementById('planet').src = new_image;
      image = image - 1;
  }
    new_image2 = images2[image2 - 1]
  if(new_image2 != '|') {
      document.getElementById('wifi').src = new_image2;
      image2 = image2 - 1;
  }
      new_image3 = images3[image3 - 1]
  if(new_image3 != '|') {
      document.getElementById('carre').src = new_image3;
      image3 = image3 - 1;
  }
}

$(document).ready(function() {
                $("#btnBlanc").click(function() {
                    $("#couleur_icones").val("blanc");
                });
            });
            $(document).ready(function() {
                $("#btnNoir").click(function() {
                    $("#couleur_icones").val("noir");
                });
            });